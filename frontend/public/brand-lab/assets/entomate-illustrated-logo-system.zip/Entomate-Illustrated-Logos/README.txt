Illustrated emblems derived from the uploaded and preview-folder references.
PNG masters retain generated alpha. The separate wordmark uses outlined vector paths.
The playground composes symbol, horizontal and stacked lockups and exports transparent PNG or SVG with embedded raster artwork.
Source images and original videos remain unchanged.
